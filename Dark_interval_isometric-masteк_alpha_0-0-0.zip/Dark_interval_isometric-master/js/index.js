import * as me from 'https://esm.run/melonjs';
import resources from './resources.js';
import PlayerEntity from './entities/player.js';
//import TitleScreen from './screens/titlescreen.js';
import PlayScreen from './screens/play.js';


/**
 *
 * Initialize the application
 */
export function onload () {
    // init the video
    if (!me.video.init(640, 480, {parent : "screen", scale : "auto"})) {
        alert("Your browser does not support HTML5 canvas.");
        return;
    }

    // Set a callback to run when loading is complete.
    me.loader.onload = loaded.bind(this);

    // set all ressources to be loaded
    me.loader.preload( resources );

    // Initialize melonJS and display a loading screen.
    me.state.change(me.state.LOADING);
};

export function loaded() {
    //me.state.set(me.state.MENU, new TitleScreen());
    me.state.set(me.state.PLAY, new PlayScreen());


    // set a global fading transition for the screen
    me.state.transition("fade", "#FFFFFF", 250);


    // add our player entity in the entity pool
    me.pool.register("mainPlayer", PlayerEntity);

    // Start the game.
    //me.state.change(me.state.MENU);
    me.state.change(me.state.PLAY);

}
export default onload