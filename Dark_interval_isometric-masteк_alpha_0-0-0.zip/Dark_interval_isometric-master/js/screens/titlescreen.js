import * as me from 'https://esm.run/melonjs';

class TitleScreen extends me.Stage {

	onResetEvent() {
		var backgroundColor = new me.Color(167, 181, 170, 100);

		me.game.world.addChild(backgroundColor);
		me.game.world.addChild(new TitleScreen());

		me.input.bindKey(me.input.KEY.ENTER, 'enter', true);

		this.handler = me.event.on(me.event.KEYDOWN, function (action, keyCode, edge){
			if (action === "enter") {
				me.state.change(me.state.PLAY);
			}
		});
	}

	/**
	 * action to perform when leaving this screen (state change)
	 */
	onDestroyEvent() {
		me.input.unbindKey(me.input.KEY.ENTER);
		me.event.off(me.event.KEYDOWN, this.handler);
	}
}

export default TitleScreen;