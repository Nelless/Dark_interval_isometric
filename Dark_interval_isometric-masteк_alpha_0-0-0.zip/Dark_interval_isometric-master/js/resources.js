var resources = [

    /* Graphics.
     * @example
     * { name: "example", type:"image", src: "data/img/example.png" },
     */
    { name: "forest",  type:"image", src: "data/img/forest.png" },
    { name: "isometric_grass_and_water",  type:"image", src: "data/img/isometric_grass_and_water.png" },
    { name: "placeholdplayerspritesheet", type:"image", src: "data/img/placeholdplayerspritesheet.png" },

    /* Maps.
     * @example
     * { name: "example01", type: "tmx", src: "data/map/example01.tmx" },
     * { name: "example01", type: "tmx", src: "data/map/example01.json" },
      */
    {name: "isometric", type: "tmx", src: "data/map/isometric.tmx"},

    /* Background music.
     * @example
     * { name: "example_bgm", type: "audio", src: "data/bgm/" },
     */
    { name: "PressStart2P", type: "binary", src: "data/img/PressStart2P.ttf"},
    { name: "PressStart2P", type: "image", src: "data/img/PressStart2P.png"}

    /* Sound effects.
     * @example
     * { name: "example_sfx", type: "audio", src: "data/sfx/" }
     */

    /* Atlases
     * @example
     * { name: "example_tps", type: "json", src: "data/img/example_tps.json" },
     */

];

export default resources;